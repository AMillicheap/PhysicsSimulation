# clothsimulation

"Cloth Simulation Using Distance Constraint - Three.js & Cannon-es Tutorial" YouTube tutorial project files https://youtu.be/PFfV7o6e_c4

1. Clone the repository;
2. Open the folder in Visual Studio Code;
3. Open the terminal and type this command: npm install
4. Run the app on the server by typing this command: npx parcel ./src/index.html
5. Ctrl + click on the server link "http://localhost:1234" to open the app in your browser;
6. Have fun!
